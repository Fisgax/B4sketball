import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:url_launcher/url_launcher.dart';
import 'intervenientes.dart';

class DadosJogoScreen extends StatefulWidget {
  const DadosJogoScreen({super.key});

  @override
  State<DadosJogoScreen> createState() => _DadosJogoScreenState();
}

class _DadosJogoScreenState extends State<DadosJogoScreen> {
  final _formKey = GlobalKey<FormState>();
  final _provaController = TextEditingController();
  final _jogoNumeroController = TextEditingController();
  final _localController = TextEditingController();
  final _dataController = TextEditingController();
  final _equipaCasaController = TextEditingController();
  final _equipaVisitanteController = TextEditingController();

  // === Função para preencher a data atual ===
  void _preencherDataAtual() {
    final agora = DateTime.now();
    final dataFormatada = '${agora.year}-${_doisDigitos(agora.month)}-${_doisDigitos(agora.day)}';
    setState(() {
      _dataController.text = dataFormatada;
    });
  }

  String _doisDigitos(int valor) => valor.toString().padLeft(2, '0');

  // === Localização automática do campo "Local" ===
  Future<void> _preencherLocalizacaoAtual() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Serviços de localização estão desativados.')),
        );
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Permissão de localização negada.')),
          );
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Permissões de localização permanentemente negadas.')),
        );
        return;
      }

      final posicao = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      final placemarks = await placemarkFromCoordinates(posicao.latitude, posicao.longitude);
      final lugar = placemarks.first;
      final nomeLocal = lugar.subLocality?.isNotEmpty == true
          ? lugar.subLocality
          : lugar.locality ?? 'Localização desconhecida';

      setState(() {
        _localController.text = nomeLocal ?? 'Desconhecido';
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao obter localização: $e')),
      );
    }
  }

  Future<void> _abrirGoogleMaps() async {
    final destino = _localController.text.trim();
    if (destino.isEmpty) return;

    final uri = Uri.parse('https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(destino)}');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não foi possível abrir o Google Maps.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dados do Jogo')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            TextFormField(
              controller: _provaController,
              decoration: const InputDecoration(labelText: 'Prova'),
              validator: (value) => value!.isEmpty ? 'Campo obrigatório' : null,
            ),
            TextFormField(
              controller: _jogoNumeroController,
              decoration: const InputDecoration(labelText: 'Jogo Nº'),
              validator: (value) => value!.isEmpty ? 'Campo obrigatório' : null,
            ),

            // Campo LOCAL com localização + Google Maps
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _localController,
                    decoration: const InputDecoration(labelText: 'Local'),
                    validator: (value) => value!.isEmpty ? 'Campo obrigatório' : null,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.my_location),
                  onPressed: _preencherLocalizacaoAtual,
                  tooltip: 'Obter localização atual',
                ),
                IconButton(
                  icon: const Icon(Icons.map),
                  onPressed: _abrirGoogleMaps,
                  tooltip: 'Abrir Google Maps',
                ),
              ],
            ),

            // Campo DATA com botão para data atual
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _dataController,
                    decoration: const InputDecoration(labelText: 'Data'),
                    validator: (value) => value!.isEmpty ? 'Campo obrigatório' : null,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.calendar_today),
                  onPressed: _preencherDataAtual,
                  tooltip: 'Usar data atual',
                ),
              ],
            ),

            TextFormField(
              controller: _equipaCasaController,
              decoration: const InputDecoration(labelText: 'Equipa da Casa'),
              validator: (value) => value!.isEmpty ? 'Campo obrigatório' : null,
            ),
            TextFormField(
              controller: _equipaVisitanteController,
              decoration: const InputDecoration(labelText: 'Equipa Visitante'),
              validator: (value) => value!.isEmpty ? 'Campo obrigatório' : null,
            ),
            const SizedBox(height: 30),

            ElevatedButton(
              onPressed: () {
                if (_formKey.currentState!.validate()) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => IntervenientesScreen(
                        prova: _provaController.text,
                        jogoNumero: _jogoNumeroController.text,
                        local: _localController.text,
                        data: _dataController.text,
                        equipaCasa: _equipaCasaController.text,
                        equipaVisitante: _equipaVisitanteController.text,
                      ),
                    ),
                  );
                }
              },
              child: const Text('Seguinte'),
            ),
          ],
        ),
      ),
    );
  }
}
